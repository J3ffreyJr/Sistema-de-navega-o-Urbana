package com.urbanav.urban_nav.api;

import com.urbanav.urban_nav.algorithm.BFS;
import com.urbanav.urban_nav.algorithm.DFS;
import com.urbanav.urban_nav.algorithm.Dijkstra;
import com.urbanav.urban_nav.graph.Grafo;
import com.urbanav.urban_nav.graph.GraphService;
import com.urbanav.urban_nav.model.NodeOsm;
import com.urbanav.urban_nav.structure.ListaLigada;
import com.urbanav.urban_nav.trie.Trie;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class RouteController {

    @Autowired private GraphService graphService;
    @Autowired private Dijkstra dijkstra;
    @Autowired private BFS bfs;
    @Autowired private DFS dfs;
    @Autowired private Trie trie;

    // GET /api/status — verifica se o grafo esta carregado
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> status() {
        Grafo grafo = graphService.getGrafo();
        Map<String, Object> resp = new HashMap<>();
        resp.put("status", "online");
        resp.put("nos", grafo.totalNos());
        resp.put("arestas", grafo.getTotalArestas());
        return ResponseEntity.ok(resp);
    }

    // GET /api/rota/dijkstra?origemLat=...&origemLon=...&destinoLat=...&destinoLon=...
    @GetMapping("/rota/dijkstra")
    public ResponseEntity<Map<String, Object>> rotaDijkstra(
            @RequestParam double origemLat,
            @RequestParam double origemLon,
            @RequestParam double destinoLat,
            @RequestParam double destinoLon) {

        Grafo grafo = graphService.getGrafo();
        NodeOsm origem  = grafo.nodoMaisProximo(origemLat, origemLon);
        NodeOsm destino = grafo.nodoMaisProximo(destinoLat, destinoLon);

        Dijkstra.ResultadoRota resultado = dijkstra.calcular(grafo, origem.getId(), destino.getId());
        return ResponseEntity.ok(formatarRota(resultado.getCaminho(), resultado.getDistanciaTotal(), "dijkstra"));
    }

    // GET /api/rota/bfs?origemLat=...&origemLon=...&destinoLat=...&destinoLon=...
    @GetMapping("/rota/bfs")
    public ResponseEntity<Map<String, Object>> rotaBFS(
            @RequestParam double origemLat,
            @RequestParam double origemLon,
            @RequestParam double destinoLat,
            @RequestParam double destinoLon) {

        Grafo grafo = graphService.getGrafo();
        NodeOsm origem  = grafo.nodoMaisProximo(origemLat, origemLon);
        NodeOsm destino = grafo.nodoMaisProximo(destinoLat, destinoLon);

        ListaLigada caminho = bfs.encontrarCaminho(grafo, origem.getId(), destino.getId());
        return ResponseEntity.ok(formatarRota(caminho, -1, "bfs"));
    }

    // GET /api/rota/dfs?origemLat=...&origemLon=...&destinoLat=...&destinoLon=...
    @GetMapping("/rota/dfs")
    public ResponseEntity<Map<String, Object>> rotaDFS(
            @RequestParam double origemLat,
            @RequestParam double origemLon,
            @RequestParam double destinoLat,
            @RequestParam double destinoLon) {

        Grafo grafo = graphService.getGrafo();
        NodeOsm origem  = grafo.nodoMaisProximo(origemLat, origemLon);
        NodeOsm destino = grafo.nodoMaisProximo(destinoLat, destinoLon);

        ListaLigada caminho = dfs.encontrarCaminho(grafo, origem.getId(), destino.getId());
        return ResponseEntity.ok(formatarRota(caminho, -1, "dfs"));
    }

    // GET /api/poi/busca?prefixo=mercado
    @GetMapping("/poi/busca")
    public ResponseEntity<List<Map<String, Object>>> buscarPOI(@RequestParam String prefixo) {
        ListaLigada resultados = trie.autocompletar(prefixo);
        List<Map<String, Object>> lista = new ArrayList<>();

        for (int i = 0; i < resultados.tamanho(); i++) {
            Trie.ResultadoTrie r = (Trie.ResultadoTrie) resultados.pega(i);
            Map<String, Object> item = new HashMap<>();
            item.put("nome", r.getNome());
            item.put("idOsm", r.getIdOsm());
            lista.add(item);
        }
        return ResponseEntity.ok(lista);
    }

    // GET /api/no/proximo?lat=...&lon=...
    @GetMapping("/no/proximo")
    public ResponseEntity<Map<String, Object>> noMaisProximo(
            @RequestParam double lat,
            @RequestParam double lon) {

        NodeOsm no = graphService.getGrafo().nodoMaisProximo(lat, lon);
        Map<String, Object> resp = new HashMap<>();
        resp.put("id", no.getId());
        resp.put("lat", no.getLat());
        resp.put("lon", no.getLon());
        resp.put("nome", no.getNome());
        return ResponseEntity.ok(resp);
    }

    // --- Auxiliar ---
    private Map<String, Object> formatarRota(ListaLigada caminho, double distancia, String algoritmo) {
        List<Map<String, Object>> pontos = new ArrayList<>();
        for (int i = 0; i < caminho.tamanho(); i++) {
            NodeOsm n = (NodeOsm) caminho.pega(i);
            Map<String, Object> ponto = new HashMap<>();
            ponto.put("lat", n.getLat());
            ponto.put("lon", n.getLon());
            ponto.put("id", n.getId());
            pontos.add(ponto);
        }
        Map<String, Object> resp = new HashMap<>();
        resp.put("algoritmo", algoritmo);
        resp.put("caminho", pontos);
        resp.put("totalNos", caminho.tamanho());
        if (distancia >= 0) resp.put("distanciaMetros", Math.round(distancia));
        return resp;
    }
}
